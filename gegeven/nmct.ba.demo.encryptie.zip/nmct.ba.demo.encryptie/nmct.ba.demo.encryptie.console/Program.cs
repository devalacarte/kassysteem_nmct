﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace nmct.ba.demo.encryptie.console
{
    class Program
    {
        static void Main(string[] args)
        {
            string Original = "NMCT";
            Console.WriteLine("Originele input: " + Original);
            
            string encrypted = Cryptography.Encrypt(Original);
            Console.WriteLine("Encrypted: " + encrypted);

            string decrypted = Cryptography.Decrypt(encrypted);
            Console.WriteLine("Decrypted: " + decrypted);

            Console.ReadLine();
        }
    }
}
